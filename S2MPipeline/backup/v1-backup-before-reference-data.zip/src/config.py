"""Centralized, injectable pipeline configuration."""
from dataclasses import dataclass
from pathlib import Path


@dataclass
class PipelineConfig:
    # --- LLM connection ---
    lm_studio_url: str = "http://localhost:1234/v1"
    model_name:    str = "qwen3.5-2b-aggressive"
    api_key:       str = "1234"
    reasoning_effort: str | None = None

    max_concurrency: int = 1          # stage 5 is always sequential

    # --- Filesystem layout ---
    input_dir:  str = "input"
    output_dir: str = "output"

    story_filename:     str = "story.txt"
    character_filename: str = "character.json"

    project_filename:          str = "1_project.json"
    assets_filename:           str = "2_assets.json"
    clips_dirname:             str = "3_clips"
    scenes_filename:           str = "3_scenes.json"
    scenes_shots_filename:     str = "4_scenes-shots.json"
    scenes_keyframes_filename: str = "5_scenes-keyframes.json"
    motion_filename:           str = "6_scenes-motion.json"
    qwen_prompts_filename:     str = "7_qwen-prompts.json"
    ltx_prompts_filename:      str = "8_ltx-prompts.json"
    qwen_export_filename:      str = "9_qwen-images.json"

    # --- Temperatures ---
    project_temperature:   float = 0.4
    assets_temperature:    float = 0.4
    clips_temperature:     float = 0.4
    shots_temperature:     float = 0.4
    keyframes_temperature: float = 0.4
    motion_temperature:    float = 0.6

    # --- Small-model limits ---
    max_context_words:   int = 500
    intro_words:         int = 250     # stage 1 reads only the story opening
    assets_window_words: int = 200     # stage 2 window
    clip_window_words:   int = 120     # stage 3 window
    memory_clips:        int = 3       # stage 3: how many done clips the LLM sees
    max_clips:           int = 60

    require_character_review: bool = False

    interactive_clip_selection: bool = True
    default_timeout:            int  = 300
    llm_max_retries:            int  = 3

    # --- Derived paths ---
    @property
    def input_path(self) -> Path:            return Path(self.input_dir)
    @property
    def story_path(self) -> Path:            return self.input_path / self.story_filename
    @property
    def character_path(self) -> Path:        return self.input_path / self.character_filename
    @property
    def project_path(self) -> Path:          return Path(self.output_dir) / self.project_filename
    @property
    def assets_path(self) -> Path:           return Path(self.output_dir) / self.assets_filename
    @property
    def clips_path(self) -> Path:            return Path(self.output_dir) / self.clips_dirname
    @property
    def scenes_path(self) -> Path:           return Path(self.output_dir) / self.scenes_filename
    @property
    def scenes_shots_path(self) -> Path:     return Path(self.output_dir) / self.scenes_shots_filename
    @property
    def scenes_keyframes_path(self) -> Path: return Path(self.output_dir) / self.scenes_keyframes_filename
    @property
    def motion_path(self) -> Path:           return Path(self.output_dir) / self.motion_filename
    @property
    def qwen_prompts_path(self) -> Path:     return Path(self.output_dir) / self.qwen_prompts_filename
    @property
    def ltx_prompts_path(self) -> Path:      return Path(self.output_dir) / self.ltx_prompts_filename
    @property
    def qwen_export_path(self) -> Path:      return Path(self.output_dir) / self.qwen_export_filename