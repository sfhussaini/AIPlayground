"""Stage 5 - per-clip first/middle/last keyframe states.

The LLM picks pose, side, facing, expression and prop for the START and the END.
Code sets depth, outfit state and condition, and builds the middle frame.
Clips with nobody in them are built entirely by code. No deltas: every Qwen
prompt is complete on its own. Sequential: a clip may start from the previous
clip's last frame.
"""
import copy
import hashlib
import time

from langchain_core.prompts import ChatPromptTemplate

from models import make_keyframe_models
from templates import (
    KEYFRAMES_END_SYSTEM, KEYFRAMES_SYSTEM, KEYFRAMES_USER, POSES, VOCABULARIES,
)
from .base import PipelineStage, iter_clips, sig


def _seed(key: str) -> int:
    return int.from_bytes(hashlib.sha256(key.encode()).digest()[:4], "big")


def _done_fn(clip: dict) -> bool:
    state = (((clip.get("keyframes") or {}).get("last") or {}).get("state") or {})
    return bool(state.get("pose_id"))


def neutral_state(character_id: str, pose: str = "pose_stand") -> dict:
    return {
        "character_id": character_id, "pose_id": pose,
        "screen_horizontal": "center", "screen_depth": "midground",
        "facing": "toward_camera", "expression": "neutral",
        "wardrobe_state": "default",
        "condition": {"wetness": "dry", "mud_level": "clean", "hair_state": "as_sheet"},
        "prop_in_hand": "none",
    }


def to_state(llm_state, character_id: str) -> dict:
    d = llm_state.model_dump()
    s = neutral_state(character_id)
    for k in ("pose_id", "screen_horizontal", "facing", "expression", "prop_in_hand"):
        s[k] = d[k]
    return s


def compute_middle(first: dict, last: dict) -> dict:
    """Middle frame: ONE category moves toward the end state."""
    mid = copy.deepcopy(first)
    if first["pose_id"] != last["pose_id"] or first["prop_in_hand"] != last["prop_in_hand"]:
        mid["pose_id"], mid["prop_in_hand"] = last["pose_id"], last["prop_in_hand"]
    elif first["screen_horizontal"] != last["screen_horizontal"]:
        order = VOCABULARIES["screen_horizontal"]
        i, j = order.index(first["screen_horizontal"]), order.index(last["screen_horizontal"])
        mid["screen_horizontal"] = order[(i + j + 1) // 2 if j > i else (i + j) // 2]
    elif first["facing"] != last["facing"]:
        mid["facing"] = last["facing"]
    elif first["expression"] != last["expression"]:
        mid["expression"] = last["expression"]
    return mid


def compute_reuse_map(scenes_data: dict) -> dict:
    """clip_id -> previous clip's last keyframe id. Same scene, same presence only."""
    result, prev = {}, None
    for scene in scenes_data.get("scenes", []):
        sid = scene["scene_id"]
        for segment in scene.get("segments", []):
            for clip in segment.get("clips", []):
                cid = clip["clip_id"]
                present = bool(clip.get("character_present"))
                cont = clip["continuity"]["transition_in"] == "continuous_from_previous"
                if cont and prev and prev[0] == sid and prev[2] == present:
                    result[cid] = f"{prev[1]}.last"
                else:
                    result[cid] = None
                prev = (sid, cid, present)
    return result


class Stage5Keyframes(PipelineStage):
    def __init__(self, llm, storage, limit: int | None = None):
        super().__init__(llm, storage)
        self._limit = limit

    @staticmethod
    def _input_sig(scene: dict, clip: dict, reuse_map: dict) -> str:
        return sig({
            "shot": clip.get("shot"), "action": clip.get("story_action"),
            "present": clip.get("character_present"), "wardrobe": clip.get("wardrobe_id"),
            "reuse": reuse_map.get(clip["clip_id"]), "light": scene.get("light"),
            "chars": scene.get("characters_present"),
        })

    def run(self) -> None:
        st, cfg = self._storage, self._llm._config
        if not st.scenes_shots_exists() or not st.assets_exists():
            print("Error: Missing output/4_scenes-shots.json or output/2_assets.json.")
            return
        if cfg.max_concurrency > 1:
            print("Note: stage 5 runs one clip at a time (clips chain).")

        clipped = st.read_scenes_shots()
        assets = st.read_assets()["assets"]
        reuse_map = compute_reuse_map(clipped)

        if st.scenes_keyframes_exists():
            kept, stale = self.merge_prior(
                clipped, st.read_scenes_keyframes(), "keyframes", "keyframes_sig",
                lambda sc, sg, c: self._input_sig(sc, c, reuse_map))
            print(f"Resuming from {cfg.scenes_keyframes_path} ({kept} kept, {stale} stale reset)")
        self._invalidate_dependents(clipped, reuse_map, None)

        clips = self._clips_for_stage(clipped, done_fn=_done_fn)
        selected = self._select(clips, "5 (Keyframes)", self._limit)
        if selected is None:
            print("Cancelled.")
            return
        pending = [(n, sc, c) for n, sc, sg, c, _ in clips if n in selected]
        if not pending:
            print("Nothing to do.")
            st.write_scenes_keyframes(clipped)
            return

        pose_ids = [p["pose_id"] for p in POSES]
        prop_ids = ["none"] + [p["prop_id"] for p in assets.get("props", [])]
        Full, End = make_keyframe_models(pose_ids, prop_ids)
        chain_full = ChatPromptTemplate.from_messages(
            [("system", KEYFRAMES_SYSTEM), ("human", KEYFRAMES_USER)]
        ) | self._llm.structured(Full, temperature=cfg.keyframes_temperature)
        chain_end = ChatPromptTemplate.from_messages(
            [("system", KEYFRAMES_END_SYSTEM), ("human", KEYFRAMES_USER)]
        ) | self._llm.structured(End, temperature=cfg.keyframes_temperature)

        names = {p["pose_id"]: p["label"] for p in POSES}
        props_by_id = {p["prop_id"]: p for p in assets.get("props", [])}
        ctx = {
            "assets": assets, "reuse_map": reuse_map,
            "clip_by_id": {c["clip_id"]: c for _, _, c in iter_clips(clipped)},
            "char_by_id": {c["character_id"]: c for c in assets["characters"]},
            "chain_full": chain_full, "chain_end": chain_end,
            "poses_list": "\n".join(f"  {pid}: {lab}" for pid, lab in names.items()),
            "props_list": "\n".join(
                ["  none: nothing in the hands"]
                + [f"  {pid}: {p['name']}" for pid, p in props_by_id.items()]),
            "names": names,
        }

        processed = failed = 0
        for num, scene, clip in pending:
            try:
                elapsed = self._process(scene, clip, ctx)
                st.write_scenes_keyframes(clipped)
                self._invalidate_dependents(clipped, reuse_map, clip["clip_id"])
                st.write_scenes_keyframes(clipped)
                processed += 1
                print(f"[{num}] done ({elapsed:.1f}s) - {clip['clip_id']}")
            except Exception as exc:
                failed += 1
                print(f"[{num}] error: {exc}")

        st.write_scenes_keyframes(clipped)
        print("\n" + "=" * 60)
        print(f"Stage 5 done. Processed: {processed}  Failed: {failed}")
        print(f"File: {cfg.scenes_keyframes_path}")

    # ------------------------------------------------------------------
    def _process(self, scene: dict, clip: dict, ctx: dict) -> float:
        clip_id = clip["clip_id"]
        if not clip.get("shot"):
            raise RuntimeError("no shot yet - run 'shots' first")

        chars = scene.get("characters_present") or []
        present = bool(clip.get("character_present")) and bool(chars)
        character_id = chars[0] if present else ""
        if present and len(chars) > 1:
            print(f"  warning: multiple characters in {scene['scene_id']}; using {character_id}")

        reuse_from = ctx["reuse_map"].get(clip_id)
        prev_last = None
        if reuse_from:
            prev = ctx["clip_by_id"].get(reuse_from.rsplit(".", 1)[0]) or {}
            prev_last = (((prev.get("keyframes") or {}).get("last") or {}).get("state"))
            if not prev_last:
                raise RuntimeError(f"previous clip ({reuse_from}) has no keyframes yet - process it first")

        t0 = time.perf_counter()
        if present:
            first, last = self._pick_states(clip, prev_last, character_id, ctx)
        else:
            first = copy.deepcopy(prev_last) if prev_last else neutral_state("", "pose_none")
            last = copy.deepcopy(first)
        mid = compute_middle(first, last)

        template = "qwen_keyframe" if present else "qwen_scene"
        kfs = {}
        for role, state, ts in (("first", first, 0.0), ("middle", mid, 2.5), ("last", last, 5.0)):
            kf = {
                "keyframe_id": f"{clip_id}.{role}", "timestamp_sec": ts,
                "reuse_from": None, "delta_from_previous": None,
                "must_preserve_extra": [],
            }
            if role == "first" and reuse_from:
                kf["reuse_from"] = reuse_from
            else:
                kf["state"] = state
                kf["image_gen"] = {
                    "task": "qwen_image_edit", "template_id": template,
                    "seed": _seed(f"{clip_id}.{role}.qwen"),
                    "status": "pending", "output_path": None, "rendered_prompt": None,
                }
            kfs[role] = kf
        clip["keyframes"] = kfs
        clip.setdefault("meta", {})["keyframes_sig"] = self._input_sig(scene, clip, ctx["reuse_map"])
        return time.perf_counter() - t0

    def _pick_states(self, clip: dict, prev_last, character_id: str, ctx: dict):
        shot = clip["shot"]
        inputs = {
            "story_action": clip["story_action"],
            "shot_summary": f"{shot['shot_type'].replace('_', ' ')}, {shot['camera_angle'].replace('_', ' ')}",
            "start_state":  self._state_text(prev_last, ctx) if prev_last else "(you choose the start)",
            "poses_list":   ctx["poses_list"],
            "props_list":   ctx["props_list"],
            "screen_horizontal_list": ", ".join(VOCABULARIES["screen_horizontal"]),
            "facing_list":            ", ".join(VOCABULARIES["facing"]),
            "expression_list":        ", ".join(VOCABULARIES["expression"]),
        }
        if prev_last:
            r = self._invoke_with_retry(ctx["chain_end"], inputs,
                                        prompts=(KEYFRAMES_END_SYSTEM, KEYFRAMES_USER))
            return copy.deepcopy(prev_last), to_state(r.last, character_id)
        r = self._invoke_with_retry(ctx["chain_full"], inputs,
                                    prompts=(KEYFRAMES_SYSTEM, KEYFRAMES_USER))
        return to_state(r.first, character_id), to_state(r.last, character_id)

    @staticmethod
    def _state_text(s: dict, ctx: dict) -> str:
        return (f"pose {s['pose_id']} ({ctx['names'].get(s['pose_id'], '')}), "
                f"side {s['screen_horizontal']}, facing {s['facing']}, "
                f"expression {s['expression']}, prop {s['prop_in_hand']}")

    @staticmethod
    def _clear(clip: dict) -> None:
        clip.pop("keyframes", None)
        (clip.get("meta") or {}).pop("keyframes_sig", None)

    def _invalidate_dependents(self, scenes: dict, reuse_map: dict, changed_id) -> None:
        """Clear keyframes of clips that start from a clip that is missing or changed."""
        dirty = {changed_id} if changed_id else set()
        have = {c["clip_id"] for _, _, c in iter_clips(scenes) if c.get("keyframes")}
        for _, _, clip in iter_clips(scenes):
            src = reuse_map.get(clip["clip_id"])
            if not src:
                continue
            prev_id = src.rsplit(".", 1)[0]
            if prev_id in dirty or prev_id not in have:
                if clip.get("keyframes"):
                    self._clear(clip)
                dirty.add(clip["clip_id"])
                have.discard(clip["clip_id"])