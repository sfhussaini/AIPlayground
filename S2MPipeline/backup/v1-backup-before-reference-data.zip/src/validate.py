"""validate.py - code-only checks. No LLM.

    python main.py validate          (every output that exists)
    python main.py check-character   (input/character.json only)
"""
import re
from typing import Dict, Iterator, List, Optional, Tuple

from pydantic import ValidationError

from models import CharacterFile
from templates import (
    BANNED_PHRASES, LIGHT_PRESETS, LLM_SYSTEM_PROMPTS, SHOT_LENS, VOCABULARIES,
)

Issue = Tuple[str, str]   # ("ERROR" | "WARN", message)

_CLOTHING = ("dress", "shirt", "wearing", "saree", "sari", "clothes", "pants",
             "jeans", "kurta", "skirt", "blouse")
_SNAKE = re.compile(r"\b[a-z0-9]+_[a-z0-9_]+\b")
_FACE = {"oval": "an oval face", "round": "a round face", "square": "a square face",
         "heart": "a heart-shaped face", "long": "a long face"}
_LEN = {"short": "short", "chin_length": "chin-length", "shoulder_length": "shoulder-length",
        "mid_back": "mid-back-length", "waist_length": "waist-length"}
_UPDO = {"braided": "in a braid", "bun": "in a bun", "ponytail": "in a ponytail",
         "tied_back": "tied back"}


def _w(s: str) -> str:
    return s.replace("_", " ")


def _flat(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").lower()).strip(" .")


# ---------------------------------------------------------------------------
# Identity lock helpers (used by stage 2)
# ---------------------------------------------------------------------------
def compose_identity_lock(ch: dict) -> str:
    i, h, subject = ch["identity"], ch["identity"]["hair"], ch["subject"]
    color = _w(h["color"])
    if h["length"] == "bald":
        hair = "a bald head"
    elif h["style"] in _UPDO:
        hair = f"{_LEN[h['length']]} {color} hair {_UPDO[h['style']]}"
    elif h["style"] == "other":
        hair = f"{_LEN[h['length']]} {color} hair"
    else:
        hair = f"{_LEN[h['length']]} {color} {h['style']} hair"
    feats = [_FACE[i["face_shape"]], f"{_w(i['skin_tone'])} skin",
             f"{_w(i['eye_color'])} eyes", hair]
    if i["facial_hair"] != "none":
        feats.append(f"a {_w(i['facial_hair'])}")
    s = f"the {subject} has {', '.join(feats[:-1])} and {feats[-1]}"
    marks = i.get("facial_marks") or []
    if marks:
        s += f", with {' and '.join(marks)}"
    return s


def lock_is_valid(lock: str, ch: dict) -> bool:
    low = (lock or "").lower().strip()
    if not (40 <= len(low) <= 300):
        return False
    if not low.startswith(f"the {ch['subject']}"):
        return False
    if any(w in low for w in _CLOTHING):
        return False
    i, h = ch["identity"], ch["identity"]["hair"]
    if _w(i["skin_tone"]) not in low:
        return False
    if h["length"] != "bald" and _w(h["color"]) not in low:
        return False
    return low.count(",") <= 4


def load_character_file(storage) -> Tuple[Optional[dict], List[Issue]]:
    issues: List[Issue] = []
    cfg = storage._config
    if not storage.character_exists():
        issues.append(("ERROR", f"Missing {cfg.character_path}. Fill it with a Vision LLM "
                                f"using input/character.schema.json."))
        return None, issues
    try:
        raw = storage.read_character_raw()
    except Exception as exc:
        issues.append(("ERROR", f"{cfg.character_path} is not valid JSON: {exc}"))
        return None, issues
    try:
        entry = CharacterFile.model_validate(raw).characters[0].model_dump()
    except ValidationError as exc:
        for e in exc.errors():
            loc = ".".join(str(p) for p in e["loc"])
            issues.append(("ERROR", f"character.json {loc}: {e['msg']}"))
        return None, issues

    if entry["sheet_file"] != f"{entry['character_id']}_sheet.png":
        issues.append(("ERROR", f"sheet_file must be {entry['character_id']}_sheet.png"))
    if not (cfg.input_path / entry["sheet_file"]).exists():
        issues.append(("ERROR", f"Character sheet not found: {cfg.input_path / entry['sheet_file']}"))
    if not lock_is_valid(entry["identity_lock"], entry):
        issues.append(("WARN", "identity_lock is not a clean sentence; it will be regenerated."))
    sc = entry["sheet_check"]
    if not sc["full_body"]:
        issues.append(("WARN", "Sheet is not full-body; poses may drift."))
    if not sc["plain_background"]:
        issues.append(("WARN", "Sheet background is not plain; scene bleed is likely."))
    for msg in sc["issues"]:
        issues.append(("WARN", f"sheet issue: {msg}"))
    if not entry["review"]["reviewed"]:
        level = "ERROR" if cfg.require_character_review else "WARN"
        issues.append((level, "review.reviewed is false. Check the file, then set it to true."))
    for f in entry["review"]["uncertain_fields"]:
        issues.append(("WARN", f"Vision LLM was unsure about: {f}"))
    return entry, issues


# ---------------------------------------------------------------------------
# Template check (RISCOR)
# ---------------------------------------------------------------------------
def check_templates() -> List[Issue]:
    out: List[Issue] = []
    headers = ["ROLE:", "INSTRUCTION:", "STEPS:", "CONTEXT:", "OUTPUT:", "RULES:"]
    for name, text in LLM_SYSTEM_PROMPTS.items():
        pos = [text.find(h) for h in headers]
        if -1 in pos:
            out.append(("ERROR", f"{name}: missing header {headers[pos.index(-1)]}"))
        elif pos != sorted(pos):
            out.append(("ERROR", f"{name}: RISCOR headers are out of order"))
        n = len(text.split())
        if n > 130:
            out.append(("ERROR", f"{name}: {n} words (limit 130)"))
    return out


# ---------------------------------------------------------------------------
# Per-stage checks
# ---------------------------------------------------------------------------
def _iter(data: dict) -> Iterator[Tuple[dict, dict, dict]]:
    for scene in data.get("scenes", []):
        for seg in scene.get("segments", []):
            for clip in seg.get("clips", []):
                yield scene, seg, clip


def check_clip_files(clips: List[dict], env_ids: List[str]) -> List[Issue]:
    out: List[Issue] = []
    if not clips:
        out.append(("ERROR", "3_clips: no clip files"))
    for c in clips:
        f = c.get("file", "?")
        for k in ("name", "action", "place", "time"):
            if not c.get(k):
                out.append(("ERROR", f"{f}: missing '{k}'"))
        if c.get("place") and c["place"] not in env_ids:
            out.append(("ERROR", f"{f}: place '{c['place']}' is not in 2_assets.json"))
        if c.get("time") and c["time"] not in VOCABULARIES["time_of_day"]:
            out.append(("ERROR", f"{f}: time '{c['time']}' not in vocabulary"))
    return out


def check_assets(assets: dict) -> List[Issue]:
    out: List[Issue] = []
    if not assets.get("characters"):
        out.append(("ERROR", "assets: no characters"))
    if not assets.get("environments"):
        out.append(("ERROR", "assets: no environments"))
    if not assets.get("pose_library"):
        out.append(("ERROR", "assets: empty pose library"))
    for c in assets.get("characters", []):
        if (c.get("sheet") or {}).get("status") != "ready":
            out.append(("ERROR", f"assets: sheet missing for {c.get('character_id')}"))
    return out


def check_scenes(data: dict, assets: dict) -> List[Issue]:
    out: List[Issue] = []
    chars = {c["character_id"] for c in assets.get("characters", [])}
    wards = {w["wardrobe_id"] for c in assets.get("characters", []) for w in c["wardrobe"]}
    seen = set()
    for scene in data.get("scenes", []):
        sid, tod = scene["scene_id"], scene.get("time_of_day")
        if tod not in VOCABULARIES["time_of_day"]:
            out.append(("ERROR", f"{sid}: time_of_day '{tod}' not in vocabulary"))
        elif scene.get("light") != LIGHT_PRESETS[tod]:
            out.append(("ERROR", f"{sid}: light does not match the '{tod}' preset"))
        for c in scene.get("characters_present", []):
            if c not in chars:
                out.append(("ERROR", f"{sid}: unknown character {c}"))
        first = True
        for seg in scene.get("segments", []):
            for clip in seg.get("clips", []):
                cid = clip["clip_id"]
                if cid in seen:
                    out.append(("ERROR", f"duplicate clip_id {cid}"))
                seen.add(cid)
                if not cid.startswith(seg["segment_id"] + "."):
                    out.append(("ERROR", f"{cid}: clip_id does not belong to {seg['segment_id']}"))
                if clip.get("wardrobe_id") not in wards:
                    out.append(("ERROR", f"{cid}: unknown wardrobe_id {clip.get('wardrobe_id')}"))
                if first and (clip.get("continuity") or {}).get("transition_in") != "hard_cut":
                    out.append(("ERROR", f"{cid}: first clip of a scene must be hard_cut"))
                first = False
    if not seen:
        out.append(("ERROR", "breakdown produced 0 clips"))
    return out


def check_shots(data: dict) -> List[Issue]:
    out: List[Issue] = []
    for _, _, clip in _iter(data):
        shot = clip.get("shot")
        if not shot:
            continue
        st = shot.get("shot_type")
        if st not in VOCABULARIES["shot_type"]:
            out.append(("ERROR", f"{clip['clip_id']}: bad shot_type {st}"))
        elif shot.get("lens_mm") != SHOT_LENS[st]:
            out.append(("ERROR", f"{clip['clip_id']}: lens {shot.get('lens_mm')} does not match {st}"))
    return out


def check_keyframes(data: dict, assets: dict) -> List[Issue]:
    out: List[Issue] = []
    poses = {p["pose_id"] for p in assets.get("pose_library", [])}
    props = {p["prop_id"] for p in assets.get("props", [])} | {"none"}
    states = {w["wardrobe_id"]: set(w["states"])
              for c in assets.get("characters", []) for w in c["wardrobe"]}
    order, scene_of = [], {}
    for scene, _, clip in _iter(data):
        order.append(clip["clip_id"])
        scene_of[clip["clip_id"]] = scene["scene_id"]

    for scene, _, clip in _iter(data):
        cid, kfs = clip["clip_id"], clip.get("keyframes")
        if not kfs:
            continue
        for role in ("first", "middle", "last"):
            kf = kfs.get(role)
            if not kf:
                out.append(("ERROR", f"{cid}: missing {role} keyframe"))
                continue
            if role == "first" and kf.get("reuse_from"):
                prev_id = kf["reuse_from"].rsplit(".", 1)[0]
                if scene_of.get(prev_id) != scene["scene_id"]:
                    out.append(("ERROR", f"{cid}.first: reuse_from crosses scenes or is unknown"))
                elif order.index(prev_id) != order.index(cid) - 1:
                    out.append(("ERROR", f"{cid}.first: reuse_from is not the previous clip"))
                if kf.get("state") or kf.get("image_gen"):
                    out.append(("ERROR", f"{cid}.first: reused keyframe must not carry state/image_gen"))
                continue
            st = kf.get("state") or {}
            if not st:
                out.append(("ERROR", f"{cid}.{role}: missing state"))
                continue
            if st.get("pose_id") not in poses:
                out.append(("ERROR", f"{cid}.{role}: pose {st.get('pose_id')} not in pose library"))
            for fld in ("screen_horizontal", "screen_depth", "facing", "expression"):
                if st.get(fld) not in VOCABULARIES[fld]:
                    out.append(("ERROR", f"{cid}.{role}: {fld}={st.get(fld)} not in vocabulary"))
            if st.get("prop_in_hand") not in props:
                out.append(("ERROR", f"{cid}.{role}: prop {st.get('prop_in_hand')} unknown"))
            allowed = states.get(clip.get("wardrobe_id"), set())
            if allowed and st.get("wardrobe_state") not in allowed:
                out.append(("ERROR", f"{cid}.{role}: wardrobe_state {st.get('wardrobe_state')} unknown"))
            ig = kf.get("image_gen") or {}
            if not ig.get("template_id") or "seed" not in ig:
                out.append(("ERROR", f"{cid}.{role}: image_gen incomplete"))
    return out


def check_prompts(data: dict) -> List[Issue]:
    """Every Qwen prompt must be complete on its own."""
    out: List[Issue] = []
    assets = data.get("assets") or {}
    envs = {e["environment_id"]: e for e in assets.get("environments", [])}
    chars = {c["character_id"]: c for c in assets.get("characters", [])}
    for scene, _, clip in _iter(data):
        env = envs.get(scene["environment_ref"]["environment_id"], {})
        for role in ("first", "middle", "last"):
            kf = (clip.get("keyframes") or {}).get(role) or {}
            ig = kf.get("image_gen")
            if not ig:
                continue
            kid, p = kf.get("keyframe_id"), ig.get("rendered_prompt")
            if not p:
                out.append(("ERROR", f"{kid}: no rendered_prompt"))
                continue
            low = _flat(p)
            if _SNAKE.search(p):
                out.append(("ERROR", f"{kid}: raw token in prompt: {_SNAKE.search(p).group(0)}"))
            if "{" in p or "}" in p:
                out.append(("ERROR", f"{kid}: unfilled slot in prompt"))
            if re.search(r"\b(None|null|nan)\b", p):
                out.append(("ERROR", f"{kid}: placeholder in prompt"))
            if re.search(r":\s*\.", p):
                out.append(("ERROR", f"{kid}: empty field in prompt"))
            for phrase in BANNED_PHRASES:
                if re.search(rf"\b{re.escape(phrase)}\b", low):
                    out.append(("ERROR", f"{kid}: banned phrase '{phrase}'"))
            if env.get("description") and _flat(env["description"]) not in low:
                out.append(("ERROR", f"{kid}: environment description missing"))
            if "lighting:" not in low:
                out.append(("ERROR", f"{kid}: lighting missing"))
            if ig.get("template_id") == "qwen_keyframe":
                st = kf.get("state") or {}
                ch = chars.get(st.get("character_id"), {})
                if ch.get("identity_lock") and _flat(ch["identity_lock"]) not in low:
                    out.append(("ERROR", f"{kid}: identity lock missing"))
                if "pose:" not in low:
                    out.append(("ERROR", f"{kid}: pose missing"))
    return out


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------
ALL_STAGES = ["templates", "character", "assets", "clips", "breakdown",
              "shots", "keyframes", "qwen-prompts"]


def check_stage(storage, stage: str) -> List[Issue]:
    if stage == "templates":
        return check_templates()
    if stage == "character":
        return load_character_file(storage)[1]
    assets = storage.read_assets()["assets"] if storage.assets_exists() else {}
    if stage == "assets":
        return check_assets(assets) if assets else [("ERROR", "2_assets.json missing")]
    if stage == "clips":
        if not storage.clips_exist():
            return []
        env_ids = [e["environment_id"] for e in assets.get("environments", [])]
        return check_clip_files(storage.read_clip_files(), env_ids)
    if stage == "breakdown":
        if not storage.scenes_exists():
            return [("ERROR", "3_scenes.json missing")]
        return check_scenes(storage.read_scenes(), assets)
    if stage == "shots":
        return check_shots(storage.read_scenes_shots()) if storage.scenes_shots_exists() else []
    if stage == "keyframes":
        return check_keyframes(storage.read_scenes_keyframes(), assets) \
            if storage.scenes_keyframes_exists() else []
    if stage == "qwen-prompts":
        return check_prompts(storage.read_qwen_prompts()) if storage.qwen_prompts_exists() else []
    return []


def report(issues: List[Issue], label: str) -> int:
    errors = sum(1 for lvl, _ in issues if lvl == "ERROR")
    print(f"[validate:{label}] {errors} error(s), {len(issues) - errors} warning(s)")
    for lvl, msg in issues[:40]:
        print(f"   {lvl}: {msg}")
    if len(issues) > 40:
        print(f"   ... and {len(issues) - 40} more")
    return errors