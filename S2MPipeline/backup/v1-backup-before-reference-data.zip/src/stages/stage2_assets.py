"""Stage 2 - assets.

Characters come from input/character.json (Vision LLM + human review).
The text LLM reads the story in windows and returns only NEW places and props.
Poses are a fixed library. No plates.
"""
import json
import re
import time

from langchain_core.prompts import ChatPromptTemplate

from models import AssetsWindowLLM
from templates import ASSETS_SYSTEM, ASSETS_USER, NO_POSE, POSES
from validate import compose_identity_lock, load_character_file, lock_is_valid
from .base import PipelineStage, sentence_windows


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "place"


class Stage2Assets(PipelineStage):
    def __init__(self, llm, storage, force: bool = False):
        super().__init__(llm, storage)
        self._force = force

    def run(self) -> None:
        if self._force:
            self._storage.delete_assets()
        if self._storage.assets_exists():
            print("Stage 2 already complete (output/2_assets.json). "
                  "Use --force to regenerate.")
            return
        if not self._check_inputs(need_story=True):
            return
        if not self._storage.project_exists():
            print("Error: Missing output/1_project.json. Run stage 'project' first.")
            return

        # --- character.json (no LLM) ------------------------------------
        entry, issues = load_character_file(self._storage)
        for lvl, msg in issues:
            print(f"  {lvl}: {msg}")
        if entry is None or any(lvl == "ERROR" for lvl, _ in issues):
            print("\nFix character.json / the character sheet and re-run this stage.")
            return

        cfg = self._llm._config
        sheet_path = cfg.input_path / entry["sheet_file"]
        lock = entry["identity_lock"]
        if not lock_is_valid(lock, entry):
            lock = compose_identity_lock(entry)
            print(f"  identity_lock regenerated: {lock}")

        character = {
            "character_id":  entry["character_id"],
            "name":          entry["name"],
            "subject":       entry["subject"],
            "identity":      entry["identity"],
            "identity_lock": lock,
            "wardrobe":      entry["wardrobe"],
            "sheet":         {"path": str(sheet_path), "status": "ready"},
            "sheet_check":   entry["sheet_check"],
            "review":        entry["review"],
        }

        # --- environments & props, window by window (LLM) ----------------
        story = self._storage.read_story()
        windows = sentence_windows(story, cfg.assets_window_words)
        print(f"Reading the story in {len(windows)} window(s)...")

        llm = self._llm.structured(AssetsWindowLLM, temperature=cfg.assets_temperature)
        prompt = ChatPromptTemplate.from_messages([
            ("system", ASSETS_SYSTEM),
            ("human",  ASSETS_USER),
        ])
        chain = prompt | llm

        envs, props = [], []
        seen_env, seen_prop = set(), set()
        t0 = time.perf_counter()
        for i, window in enumerate(windows, start=1):
            try:
                result: AssetsWindowLLM = self._invoke_with_retry(chain, {
                    "window":       window,
                    "known_places": ", ".join(e["name"] for e in envs) or "(none)",
                    "known_props":  ", ".join(p["name"] for p in props) or "(none)",
                }, prompts=(ASSETS_SYSTEM, ASSETS_USER))
            except Exception as exc:
                print(f"  window {i}: error: {exc}")
                continue
            for e in result.environments:
                key = _slug(e.name)
                if key in seen_env:
                    continue
                seen_env.add(key)
                envs.append({
                    "environment_id": f"env_{key}",
                    "name":           e.name.strip(),
                    "description":    e.description.strip(),
                    "ambience":       e.ambience.strip(),
                })
            for p in result.props:
                key = _slug(p.name)
                if key in seen_prop:
                    continue
                seen_prop.add(key)
                props.append({"prop_id": f"prop_{len(props) + 1:02d}",
                              "name": p.name.strip(), "text": p.text.strip()})
            print(f"  window {i}/{len(windows)}: {len(envs)} places, {len(props)} props so far")
        print(f"LLM assets took {time.perf_counter() - t0:.2f}s")

        if not envs:
            print("Error: no places found in the story.")
            return

        data = {
            "schema_version": "2.0",
            "assets": {
                "characters":   [character],
                "environments": envs,
                "props":        props,
                "pose_library": [dict(p) for p in POSES] + [dict(NO_POSE)],
            },
        }
        self._storage.write_assets(data)
        print(f"Wrote {cfg.assets_path} ({len(envs)} places, {len(props)} props)")