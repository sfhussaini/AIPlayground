"""CLI entry point for the story pipeline."""
import argparse
import sys

from pipeline import StoryPipeline, PipelineConfig

STAGES = [
    "project", "assets", "breakdown", "shots", "keyframes", "motion",
    "qwen-prompts", "ltx-prompts", "qwen-export",
    "validate", "check-character", "all",
]


def parse_args():
    p = argparse.ArgumentParser(description="Story -> Video Data Flow Pipeline")
    p.add_argument("stage", choices=STAGES, help="Which stage to run.")
    p.add_argument("--force", action="store_true",
                   help="Regenerate stages 1, 2, 3 (deletes their output; stage 3 also "
                        "deletes output/3_clips/).")
    p.add_argument("--all-clips", action="store_true",
                   help="Skip the clip selection prompt (stages 4, 5, 6).")
    p.add_argument("--limit", type=int, default=None,
                   help="Process only the first N pending items.")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    cfg = PipelineConfig()
    if args.all_clips or not sys.stdin.isatty():
        cfg.interactive_clip_selection = False

    force = args.force
    if force and args.stage in ("shots", "keyframes", "motion"):
        print("Note: --force is not applicable to filling stages (4-6); "
              "use clip selection to reprocess [DONE] clips.")
        force = False

    pipeline = StoryPipeline(cfg)

    if args.stage == "project":
        pipeline.generate_project(force=force)
    elif args.stage == "assets":
        pipeline.generate_assets(force=force)
    elif args.stage == "breakdown":
        pipeline.breakdown_story(force=force)
    elif args.stage == "shots":
        pipeline.fill_shots(limit=args.limit)
    elif args.stage == "keyframes":
        pipeline.fill_keyframes(limit=args.limit)
    elif args.stage == "motion":
        pipeline.fill_motion(limit=args.limit)
    elif args.stage == "qwen-prompts":
        pipeline.fill_qwen_prompts(force=force, limit=args.limit)
    elif args.stage == "ltx-prompts":
        pipeline.fill_ltx_prompts(force=force, limit=args.limit)
    elif args.stage == "qwen-export":
        return pipeline.export_qwen_images()
    elif args.stage == "validate":
        return 1 if pipeline.validate() else 0
    elif args.stage == "check-character":
        return 1 if pipeline.validate(["character"]) else 0
    elif args.stage == "all":
        pipeline.run_all(force=force)
    return 0


if __name__ == "__main__":
    sys.exit(main())