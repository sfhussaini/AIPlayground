"""
templates.py - closed vocabularies, fixed libraries, RISCOR prompts for the
2B LLM, and sentence templates for Qwen / LTX. Constants only.
"""

# =========================================================================
# CLOSED VOCABULARIES & FIXED LIBRARIES
# =========================================================================

VOCABULARIES = {
    "shot_type": ["extreme_wide", "wide", "medium_wide", "medium",
                  "medium_close", "close_up", "extreme_close_up"],
    "camera_angle": ["eye_level", "low_angle", "high_angle",
                     "over_the_shoulder", "dutch"],
    "camera_movement": ["static", "slow_push_in", "slow_pull_out"],
    "lens_mm": [24, 35, 50, 85],
    "screen_horizontal": ["left_third", "center", "right_third"],
    "screen_depth": ["foreground", "midground", "background"],
    "facing": ["toward_camera", "away_from_camera", "left", "right",
               "three_quarter_left", "three_quarter_right"],
    "expression": ["neutral", "calm", "focused", "tired", "content",
                   "relieved", "smiling", "worried", "afraid"],
    "wetness": ["dry", "damp", "wet", "soaked"],
    "mud_level": ["clean", "light", "moderate", "heavy"],
    "hair_state": ["as_sheet", "windblown", "wet"],
    "time_of_day": ["pre_dawn", "dawn", "morning", "noon", "afternoon",
                    "golden_hour", "dusk", "night"],
    "transition_in": ["hard_cut", "continuous_from_previous"],
}

SHOT_LENS = {
    "extreme_wide": 24, "wide": 35, "medium_wide": 35, "medium": 50,
    "medium_close": 50, "close_up": 85, "extreme_close_up": 85,
}

COLOR_GRADES = ["warm natural", "muted natural", "cool natural",
                "soft pastel", "high contrast"]

LIGHT_PRESETS = {
    "pre_dawn":    {"source": "faint glow before sunrise", "direction": "low on the horizon",
                    "quality": "soft and diffused", "color_temp": "cool blue"},
    "dawn":        {"source": "early morning sun", "direction": "low angle from the side",
                    "quality": "soft", "color_temp": "warm golden"},
    "morning":     {"source": "morning sun", "direction": "medium angle from the side",
                    "quality": "soft", "color_temp": "warm"},
    "noon":        {"source": "midday sun", "direction": "overhead",
                    "quality": "bright and hard", "color_temp": "neutral white"},
    "afternoon":   {"source": "afternoon sun", "direction": "high angle from the side",
                    "quality": "bright", "color_temp": "warm neutral"},
    "golden_hour": {"source": "low golden sun", "direction": "low angle",
                    "quality": "soft and warm", "color_temp": "golden"},
    "dusk":        {"source": "fading sun", "direction": "very low angle",
                    "quality": "soft and dim", "color_temp": "orange to blue"},
    "night":       {"source": "moonlight", "direction": "from above",
                    "quality": "dim", "color_temp": "cool blue"},
}

POSES = [
{
  "pose_id": "pose_stand",
  "label": "standing",
  "text": "standing upright with arms relaxed at the sides and legs straight"
},
{
  "pose_id": "pose_walk",
  "label": "walking",
  "text": "walking forward with one foot ahead of the other and arms swinging gently"
},
{
  "pose_id": "pose_bend_work",
  "label": "bending to work",
  "text": "bent forward at the waist with knees slightly bent and both hands low, working at ground level"
},
{
  "pose_id": "pose_wipe_brow",
  "label": "wiping the brow",
  "text": "standing with one hand raised to the forehead, wiping the brow, the other arm relaxed"
},
{
  "pose_id": "pose_sit",
  "label": "sitting",
  "text": "sitting cross-legged on the ground with a straight back and hands resting on the lap"
},
{
  "pose_id": "pose_hold_prop",
  "label": "holding an object",
  "text": "holding an object in both hands in front of the body with elbows bent"
},
{
  "pose_id": "pose_eat",
  "label": "eating",
  "text": "sitting, one hand raised bringing food to the mouth, the other hand holding a container on the lap"
},
{
  "pose_id": "pose_listen",
  "label": "listening",
  "text": "sitting still with the head tilted slightly to one side and hands resting calmly"
},
{
  "pose_id": "pose_reach",
  "label": "reaching forward",
  "text": "reaching forward with one arm extended and the other arm relaxed"
},
{
  "pose_id": "pose_stand_work",
  "label": "standing work",
  "text": "standing upright with knees slightly bent and hands clasped behind back, looking at the object"
},
{
  "pose_id": "pose_sit_work",
  "label": "sitting work",
  "text": "sitting at a desk or table with arms crossed over chest and head resting on hands"
},
{
  "pose_id": "pose_gymnastic_bow",
  "label": "gymnastic",
  "text": "kneeling on hands and toes with one arm extended and other bent back to the side, performing a bend"
},
{
  "pose_id": "pose_sleep",
  "label": "sleeping",
  "text": "lying down in a prone position with head turned slightly to the side, hands resting on knees"
},
{
  "pose_id": "pose_sleeping_stretch",
  "label": "sleeping stretch",
  "text": "lying on side with legs straight and arms reaching towards the ceiling, hands interlaced"
},
{
  "pose_id": "pose_lift_grip",
  "label": "lifting grip",
  "text": "lifting one hand to shoulder height holding a cup or bottle, then lowering to lap"
},
{
  "pose_id": "pose_drinking",
  "label": "drinking",
  "text": "standing with one hand holding a glass, tilting head back slightly to drink from the glass"
},
{
  "pose_id": "pose_sing",
  "label": "singing",
  "text": "standing on one foot with arms raised above shoulders in a rhythmic motion"
},
{
  "pose_id": "pose_laugh",
  "label": "laughing",
  "text": "standing with head tilted slightly back, hands raised to chest in a playful gesture"
},
{
  "pose_id": "pose_smile",
  "label": "smiling",
  "text": "standing with hands resting on hips or holding a cup close to the mouth, looking directly at the camera"
},
{
  "pose_id": "pose_gesture",
  "label": "gesturing",
  "text": "standing with one hand raised high in a circular motion, eyes following the motion"
},
{
  "pose_id": "pose_wiggle",
  "label": "wiggling",
  "text": "standing with both hands making small movements near the neck or shoulders"
},
{
  "pose_id": "pose_stare",
  "label": "staring",
  "text": "standing still with the head tilted slightly to one side and hands resting calmly"
},
{
  "pose_id": "pose_mature_seductive",
  "label": "mature seductive",
  "text": "sitting on a high-backed chair with legs crossed at the ankles, hands resting on the lap"
},
{
  "pose_id": "pose_mature_smirk",
  "label": "mature smirk",
  "text": "standing with head turned to the side, hand raised in a relaxed manner"
},
{
  "pose_id": "pose_mature_seductive",
  "label": "mature seductive",
  "text": "sitting cross-legged on a couch with one leg pulled up, hands folded on the lap"
}
]
NO_POSE = {"pose_id": "pose_none", "label": "nobody", "text": "no person in the frame"}

HORIZONTAL_LABELS = {"left_third": "left third", "center": "center", "right_third": "right third"}
DEPTH_LABELS = {"foreground": "in the foreground", "midground": "in the midground",
                "background": "in the background"}
FACING_LABELS = {
    "toward_camera": "facing the camera",
    "away_from_camera": "facing away from the camera",
    "left": "facing left",
    "right": "facing right",
    "three_quarter_left": "facing three-quarter left",
    "three_quarter_right": "facing three-quarter right",
}
CONDITION_TEXT = {
    "wetness":    {"damp": "clothes are damp", "wet": "clothes are wet",
                   "soaked": "clothes are soaked"},
    "mud_level":  {"light": "light mud splatter on legs and clothes",
                   "moderate": "moderate mud on legs and clothes",
                   "heavy": "heavy mud covering legs and clothes"},
    "hair_state": {"windblown": "hair is windblown", "wet": "hair is wet"},
}

NEGATIVES_STILL = [
    "cartoon", "anime", "3D render", "illustration", "text", "watermark", "logo",
    "extra fingers", "extra limbs", "deformed hands", "distorted face",
    "different face", "different outfit", "duplicate person", "blurry",
    "low quality", "oversaturated",
]
NEGATIVES_VIDEO = [
    "jump cut", "teleport", "morph", "dissolve", "glitch", "stutter", "flicker",
    "duplicate face", "warped limbs", "extra fingers", "cartoon",
]

STYLE_PRESETS = {
    "photorealistic": {
        "art_medium_style": "photorealistic cinematic film still, natural light, film grain",
        "quality_tags": "shallow depth of field, 35mm film look, natural colors",
    },
    "cinematic": {
        "art_medium_style": "cinematic film still, anamorphic lens, dramatic lighting",
        "quality_tags": "shallow depth of field, strong contrast, color graded",
    },
    "anime": {
        "art_medium_style": "anime key visual, studio quality, hand-drawn look",
        "quality_tags": "clean line art, vibrant colors, expressive",
    },
    "digital_art": {
        "art_medium_style": "digital painting, concept art, painterly style",
        "quality_tags": "loose brushwork, atmospheric, storytelling composition",
    },
}

# Phrases that must never appear in a Qwen prompt (prompts are stateless).
BANNED_PHRASES = ["change", "a moment later", "previous frame", "unchanged",
                  "same as before", "image 1", "image 2"]


# =========================================================================
# SENTENCE TEMPLATES (Qwen / LTX). A sentence with any empty slot is dropped.
# No image-slot wording: Comfy owns which image goes where.
# =========================================================================

PROMPT_TEMPLATES = {
    "qwen_keyframe": [
        "Using the character reference, show the same {subject} in {environment_description}.",
        "{identity_lock}.",
        "Wearing {wardrobe_text}.",
        "{wardrobe_state_text}.",
        "Framing: {framing_text}.",
        "Pose: {pose_text}.",
        "Position: {position_text}.",
        "Expression: {expression_text}.",
        "Holding {prop_text}.",
        "{condition_text}.",
        "Lighting: {light_text}.",
        "{style_text}.",
        "Keep the face, hair, skin tone, body build and outfit identical to the character reference.",
    ],
    "qwen_scene": [
        "{style_text}.",
        "{environment_description}.",
        "No people in the frame.",
        "Framing: {framing_text}.",
        "Lighting: {light_text}.",
    ],
    "ltx_motion": [
        "{shot_type} shot, {camera_movement} camera.",
        "{action_sentence}.",
        "{secondary_sentence}.",
        "{ambient_sentence}.",
        "{style_text}.",
        "Smooth continuous motion, present tense, chronological action.",
    ],
}


# =========================================================================
# LLM PROMPTS - RISCOR (Role, Instruction, Steps, Context, Output, Rules)
# Child-simple. Keep each system prompt under about 110 words.
# =========================================================================

PROJECT_RULES_SYSTEM = """\
ROLE:
You pick the look of a movie.

INSTRUCTION:
Pick a title, a style, and a color for the movie.

STEPS:
1. Read the story start.
2. Write a short title.
3. Pick one style from my list.
4. Pick one color from my list.

CONTEXT:
The movie is short, calm, and real. Code decides all other rules. You only choose.

OUTPUT:
title, style_preset, color_grade.

RULES:
- The title has 3 to 6 words.
- Do not write about the story.
- Do not invent new words.
- Pick only from my lists.
"""

PROJECT_RULES_USER = """\
STORY START:
{story}

STYLE LIST: {style_presets}
COLOR LIST: {color_grades}

Now pick.
"""


ASSETS_SYSTEM = """\
ROLE:
You find places and objects in a story.

INSTRUCTION:
List the NEW places and NEW objects in this story part.

STEPS:
1. Read the story part.
2. Read the names I already know.
3. Find places that are not known.
4. Find objects the person holds or uses that are not known.

CONTEXT:
You see a small part of a long story. A place is where things happen. An object is a thing the person holds.

OUTPUT:
environments (name, description, ambience) and props (name, text). Use empty lists if nothing is new.

RULES:
- Never describe a person or clothes.
- Do not list a known name again.
- Use simple words. One short sentence for description and text.
- Only list what the story says.
"""

ASSETS_USER = """\
STORY PART:
{window}

KNOWN PLACES: {known_places}
KNOWN PROPS: {known_props}

Now list the new ones.
"""


CLIP_SYSTEM = """\
ROLE:
You cut a story into short clips.

INSTRUCTION:
Write the NEXT clip of the story.

STEPS:
1. Read the story part.
2. Read the clips already done.
3. Find the next action.
4. Write it as one clip.

CONTEXT:
Each clip is 5 seconds. A clip has one action only. You see a small part of the story, not all of it.

OUTPUT:
done, name, action, place, time, person, last_words. Say done when no action is left.

RULES:
- Keep the story order.
- Never repeat a done clip.
- Pick place and time only from my lists.
- last_words: copy the 3 story words where your action ends.
- done is True only when the whole story is finished.
- Always write one clip per call, then stop.
- If you cannot find a new action, set done to true; do not repeat the previous action.
"""

CLIP_USER = """\
STORY PART:
{window}

CLIPS ALREADY DONE:
{done_clips}

NOW: place is {current_place}. time is {current_time}.

place LIST: {place_list}
time LIST: {time_list}

Now write the next clip.
"""


SHOTS_SYSTEM = """\
ROLE:
You plan the camera for one clip.

INSTRUCTION:
Pick the camera for this clip.

STEPS:
1. Read the action.
2. Pick one shot_type.
3. Pick one camera_angle.
4. Pick one camera_movement.

CONTEXT:
The clip is 5 seconds. The camera stays still unless the person travels.

OUTPUT:
shot_type, camera_angle, camera_movement.

RULES:
- Pick only from my lists.
- Use static for most clips.
- Use slow_push_in or slow_pull_out only for walking or travel.
- Use wide shots when nobody is in the clip.
"""

SHOTS_USER = """\
CLIP: {clip_name}
ACTION: {story_action}
PLACE: {place_name}
TIME: {time_of_day}
PERSON IN CLIP: {person}

shot_type LIST: {shot_type_list}
camera_angle LIST: {camera_angle_list}
camera_movement LIST: {camera_movement_list}

Now pick.
"""


KEYFRAMES_SYSTEM = """\
ROLE:
You describe the START and the END of one action.

INSTRUCTION:
Pick values for the first picture and the last picture.

STEPS:
1. Read the action.
2. Pick the START: pose, side, facing, expression, prop.
3. Pick the END the same way.
4. Make the pose show the action.

CONTEXT:
The camera stays still. The person looks the same in both pictures. Example: "walks to the tree" starts with pose_stand and ends with pose_walk. Example: "listens" starts and ends with the same pose.

OUTPUT:
first and last. Each has pose_id, screen_horizontal, facing, expression, prop_in_hand.

RULES:
- Pick only from my lists.
- Do not write sentences.
- If the action moves, change the pose or the side.
- If the action is still, change only the expression.
"""

KEYFRAMES_END_SYSTEM = """\
ROLE:
You describe the END of one action.

INSTRUCTION:
The START is fixed. Pick values for the last picture.

STEPS:
1. Read the action.
2. Read the START.
3. Pick the END: pose, side, facing, expression, prop.
4. Make the pose show the action.

CONTEXT:
The camera stays still. The person looks the same. Example: START is pose_stand and the action is "sits down". END is pose_sit.

OUTPUT:
last. It has pose_id, screen_horizontal, facing, expression, prop_in_hand.

RULES:
- Pick only from my lists.
- Do not write sentences.
- If the action moves, change the pose or the side.
- If the action is still, change only the expression.
"""

KEYFRAMES_USER = """\
ACTION: {story_action}
SHOT: {shot_summary}

START:
{start_state}

POSES:
{poses_list}

PROPS:
{props_list}

screen_horizontal LIST: {screen_horizontal_list}
facing LIST: {facing_list}
expression LIST: {expression_list}

Now pick.
"""


MOTION_SYSTEM = """\
ROLE:
You write what happens in a 5-second video.

INSTRUCTION:
Write the motion for this clip.

STEPS:
1. Read the action.
2. Look at the first and last pictures.
3. Write what the person does from start to end.
4. Write what the world does.

CONTEXT:
The camera is still. The video must look smooth. If nobody is in the clip, leave subject_motion empty.

OUTPUT:
subject_motion, ambient_motion.

RULES:
- Use present tense.
- Write full sentences of 10 to 25 words.
- Do not write about the camera.
- Only write what we can see.
"""

MOTION_USER = """\
ACTION: {story_action}
SHOT: {shot_summary}
PERSON IN CLIP: {person}

FIRST PICTURE: {first_summary}
LAST PICTURE: {last_summary}

PLACE SOUNDS: {scene_ambience}

Now write the motion.
"""

# Used by validate.check_templates()
LLM_SYSTEM_PROMPTS = {
    "PROJECT_RULES_SYSTEM": PROJECT_RULES_SYSTEM,
    "ASSETS_SYSTEM": ASSETS_SYSTEM,
    "CLIP_SYSTEM": CLIP_SYSTEM,
    "SHOTS_SYSTEM": SHOTS_SYSTEM,
    "KEYFRAMES_SYSTEM": KEYFRAMES_SYSTEM,
    "KEYFRAMES_END_SYSTEM": KEYFRAMES_END_SYSTEM,
    "MOTION_SYSTEM": MOTION_SYSTEM,
}