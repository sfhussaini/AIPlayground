"""All filesystem access for the pipeline (I/O isolation)."""
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterator, List

from config import PipelineConfig


class StoryStorage:
    def __init__(self, config: PipelineConfig):
        self._config = config

    # --- directories / atomic write -----------------------------------
    def ensure_output_dir(self) -> None:
        Path(self._config.output_dir).mkdir(parents=True, exist_ok=True)

    def ensure_tmp_dir(self) -> Path:
        p = Path(self._config.output_dir) / "tmp"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _atomic_write(self, final_path: Path, content: str) -> None:
        tmp_dir = self.ensure_tmp_dir()
        tmp_path = tmp_dir / f"{final_path.name}.{os.getpid()}.tmp"
        try:
            tmp_path.write_text(content, encoding="utf-8")
            final_path.parent.mkdir(parents=True, exist_ok=True)
            os.replace(tmp_path, final_path)
        finally:
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass

    # --- inputs --------------------------------------------------------
    def validate_inputs(self, need_story: bool = True) -> List[str]:
        errors: List[str] = []
        if need_story:
            if not self._config.story_path.exists():
                errors.append(f"Missing story file: {self._config.story_path}")
            elif not self._config.story_path.read_text(encoding="utf-8").strip():
                errors.append(f"Story file is empty: {self._config.story_path}")
        return errors

    def read_story(self) -> str:
        return self._config.story_path.read_text(encoding="utf-8")

    def discover_character_sheets(self) -> Dict[str, Path]:
        pattern = re.compile(r"^(char_\d{2})_sheet\.png$", re.IGNORECASE)
        sheets: Dict[str, Path] = {}
        input_dir = self._config.input_path
        if not input_dir.exists():
            return sheets
        for f in sorted(input_dir.iterdir()):
            m = pattern.match(f.name)
            if m:
                sheets[m.group(1)] = f
        return sheets

    def character_exists(self) -> bool:
        return self._config.character_path.exists()

    def read_character_raw(self) -> Dict[str, Any]:
        return json.loads(self._config.character_path.read_text(encoding="utf-8"))

    # --- freshness -----------------------------------------------------
    @staticmethod
    def is_newer(a: Path, b: Path) -> bool:
        """True when both files exist and a was modified after b."""
        return a.exists() and b.exists() and a.stat().st_mtime > b.stat().st_mtime

    # --- json helpers --------------------------------------------------
    def _read_json(self, path: Path) -> Dict[str, Any]:
        return json.loads(path.read_text(encoding="utf-8"))

    def _write_json(self, path: Path, data: Dict[str, Any]) -> None:
        self._atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))

    # --- 1 project / 2 assets -----------------------------------------
    def project_exists(self) -> bool:              return self._config.project_path.exists()
    def read_project(self)  -> Dict[str, Any]:     return self._read_json(self._config.project_path)
    def write_project(self, d: Dict[str, Any]):    self._write_json(self._config.project_path, d)
    def delete_project(self) -> None:              self._config.project_path.unlink(missing_ok=True)

    def assets_exists(self) -> bool:               return self._config.assets_path.exists()
    def read_assets(self)   -> Dict[str, Any]:     return self._read_json(self._config.assets_path)
    def write_assets(self, d: Dict[str, Any]):     self._write_json(self._config.assets_path, d)
    def delete_assets(self) -> None:               self._config.assets_path.unlink(missing_ok=True)

    # --- 3 clips (txt) and scenes (json) -------------------------------
    def clips_exist(self) -> bool:
        d = self._config.clips_path
        return d.exists() and any(d.glob("clip_*.txt"))

    def delete_clips(self) -> None:
        d = self._config.clips_path
        if d.exists():
            for f in d.glob("clip_*.txt"):
                f.unlink(missing_ok=True)

    def write_clip_file(self, n: int, clip: Dict[str, Any]) -> None:
        def one_line(v) -> str:
            return " ".join(str(v).split())
        text = "\n".join([
            f"name: {one_line(clip['name'])}",
            f"action: {one_line(clip['action'])}",
            f"place: {one_line(clip['place'])}",
            f"time: {one_line(clip['time'])}",
            f"person: {'yes' if clip['person'] else 'no'}",
        ]) + "\n"
        self._atomic_write(self._config.clips_path / f"clip_{n:03d}.txt", text)

    def read_clip_files(self) -> List[Dict[str, Any]]:
        clips: List[Dict[str, Any]] = []
        for f in sorted(self._config.clips_path.glob("clip_*.txt")):
            row: Dict[str, Any] = {"file": f.name}
            for line in f.read_text(encoding="utf-8").splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    row[k.strip().lower()] = v.strip()
            row["person"] = str(row.get("person", "yes")).lower() in ("yes", "true", "1")
            clips.append(row)
        return clips

    def scenes_exists(self) -> bool:               return self._config.scenes_path.exists()
    def read_scenes(self)   -> Dict[str, Any]:     return self._read_json(self._config.scenes_path)
    def write_scenes(self, d: Dict[str, Any]):     self._write_json(self._config.scenes_path, d)
    def delete_scenes(self) -> None:               self._config.scenes_path.unlink(missing_ok=True)

    # --- 4 / 5 / 6 -----------------------------------------------------
    def scenes_shots_exists(self) -> bool:           return self._config.scenes_shots_path.exists()
    def read_scenes_shots(self)   -> Dict[str, Any]: return self._read_json(self._config.scenes_shots_path)
    def write_scenes_shots(self, d: Dict[str, Any]): self._write_json(self._config.scenes_shots_path, d)

    def scenes_keyframes_exists(self) -> bool:       return self._config.scenes_keyframes_path.exists()
    def read_scenes_keyframes(self) -> Dict[str, Any]: return self._read_json(self._config.scenes_keyframes_path)
    def write_scenes_keyframes(self, d: Dict[str, Any]): self._write_json(self._config.scenes_keyframes_path, d)

    def motion_exists(self) -> bool:               return self._config.motion_path.exists()
    def read_motion(self)   -> Dict[str, Any]:     return self._read_json(self._config.motion_path)
    def write_motion(self, d: Dict[str, Any]):     self._write_json(self._config.motion_path, d)

    # --- 7 / 8 / 9 -----------------------------------------------------
    def qwen_prompts_exists(self) -> bool:         return self._config.qwen_prompts_path.exists()
    def read_qwen_prompts(self)   -> Dict[str, Any]: return self._read_json(self._config.qwen_prompts_path)
    def write_qwen_prompts(self, d: Dict[str, Any]): self._write_json(self._config.qwen_prompts_path, d)

    def ltx_prompts_exists(self) -> bool:          return self._config.ltx_prompts_path.exists()
    def read_ltx_prompts(self)   -> Dict[str, Any]: return self._read_json(self._config.ltx_prompts_path)
    def write_ltx_prompts(self, d: Dict[str, Any]): self._write_json(self._config.ltx_prompts_path, d)

    def write_qwen_export(self, d: Dict[str, Any]): self._write_json(self._config.qwen_export_path, d)

    # --- traversal -----------------------------------------------------
    def iter_clips(self, scenes_data: Dict[str, Any]) -> Iterator[tuple[dict, dict, dict]]:
        for scene in scenes_data.get("scenes", []):
            for segment in scene.get("segments", []):
                for clip in segment.get("clips", []):
                    yield scene, segment, clip