# Story → Video Pipeline

Plans a movie from a story: one 5-second clip at a time. Qwen Image Edit makes
the keyframes, LTX makes the clips, FFmpeg joins them (outside this program).

## Inputs (./input/)
- story.txt              required (up to about 1500 words)
- char_01_sheet.png      required: neutral background, full body
- character.json         required: filled by a Vision LLM from the sheet, then
                         reviewed by you (schema: character.schema.json).
                         Set review.reviewed to true when checked.

## Outputs (./output/)
- 1_project.json            style, negatives
- 2_assets.json             character, places, props, fixed poses
- 3_clips/clip_NNN.txt      one clip per file (editable by hand)
- 3_scenes.json             scenes, segments, clips
- 4_scenes-shots.json       + camera per clip
- 5_scenes-keyframes.json   + first/middle/last states per clip
- 6_scenes-motion.json      + motion and audio per clip
- 7_qwen-prompts.json       + a complete Qwen prompt per keyframe
- 8_ltx-prompts.json        + an LTX prompt per clip (final artifact)
- 9_qwen-images.json        flat list of Qwen jobs for Comfy

## Commands
python main.py check-character
python main.py project   [--force]
python main.py assets    [--force]
python main.py breakdown [--force]     (--force deletes 3_clips/, losing hand edits)
python main.py shots | keyframes | motion   [--all-clips] [--limit N]
python main.py qwen-prompts
python main.py ltx-prompts
python main.py qwen-export
python main.py validate
python main.py all [--force]

## Notes
- The LLM does all language work. Code only handles files, ids, seeds, fixed
  libraries and string matching.
- Each LLM call stays under 500 words (a warning prints if it does not).
- To rebuild 3_scenes.json after editing clip files, delete 3_scenes.json.
- Re-running an earlier stage resets only the downstream clips whose inputs changed.