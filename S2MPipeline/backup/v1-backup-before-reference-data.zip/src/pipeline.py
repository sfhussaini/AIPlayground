"""StoryPipeline - the orchestrator."""
from config import PipelineConfig
from llm_client import LLMClient
from storage import StoryStorage
from validate import ALL_STAGES, check_stage, report
from stages.stage1_project      import Stage1Project
from stages.stage2_assets       import Stage2Assets
from stages.stage3_breakdown    import Stage3Breakdown
from stages.stage4_shots        import Stage4Shots
from stages.stage5_keyframes    import Stage5Keyframes
from stages.stage6_motion       import Stage6Motion
from stages.stage7_qwen_prompts import Stage7QwenPrompts
from stages.stage8_ltx_prompts  import Stage8LtxPrompts


class StoryPipeline:
    def __init__(self, config: PipelineConfig | None = None):
        self.config  = config or PipelineConfig()
        self.llm     = LLMClient(self.config)
        self.storage = StoryStorage(self.config)

    # --- structural stages (1-3) ---------------------------------------
    def generate_project(self, force: bool = False) -> None:
        Stage1Project(self.llm, self.storage, force=force).run()

    def generate_assets(self, force: bool = False) -> None:
        Stage2Assets(self.llm, self.storage, force=force).run()

    def breakdown_story(self, force: bool = False) -> None:
        Stage3Breakdown(self.llm, self.storage, force=force).run()

    # --- filling stages (4-6) ------------------------------------------
    def fill_shots(self, limit: int | None = None) -> None:
        Stage4Shots(self.llm, self.storage, limit=limit).run()

    def fill_keyframes(self, limit: int | None = None) -> None:
        Stage5Keyframes(self.llm, self.storage, limit=limit).run()

    def fill_motion(self, limit: int | None = None) -> None:
        Stage6Motion(self.llm, self.storage, limit=limit).run()

    # --- rendering stages (7-8) + export --------------------------------
    def fill_qwen_prompts(self, force: bool = False, limit: int | None = None) -> None:
        Stage7QwenPrompts(self.llm, self.storage, force=force, limit=limit).run()

    def fill_ltx_prompts(self, force: bool = False, limit: int | None = None) -> None:
        Stage8LtxPrompts(self.llm, self.storage, force=force, limit=limit).run()

    def export_qwen_images(self) -> int:
        from util.qwen import export
        return export(self.config)

    # --- validation -----------------------------------------------------
    def validate(self, stages: list[str] | None = None) -> int:
        errors = 0
        for key in (stages or ALL_STAGES):
            errors += report(check_stage(self.storage, key), key)
        return errors

    def _gate(self, key: str, abort: bool = True) -> bool:
        errors = report(check_stage(self.storage, key), key)
        return not (abort and errors)

    # --- end-to-end ----------------------------------------------------
    def run_all(self, force: bool = False) -> None:
        self.generate_project(force=force)
        if not self.storage.project_exists():
            print("Aborted: Stage 1 did not produce output.")
            return
        self.generate_assets(force=force)
        if not self.storage.assets_exists() or not self._gate("assets"):
            print("Aborted: Stage 2 did not produce valid output.")
            return
        self.breakdown_story(force=force)
        if not self.storage.scenes_exists() or not self._gate("breakdown"):
            print("Aborted: Stage 3 did not produce valid output.")
            return
        self.fill_shots()
        self.fill_keyframes()
        self._gate("keyframes", abort=False)
        self.fill_motion()
        self.fill_qwen_prompts()
        self._gate("qwen-prompts", abort=False)
        self.fill_ltx_prompts()
        self.export_qwen_images()