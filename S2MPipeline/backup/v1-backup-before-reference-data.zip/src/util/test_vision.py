# util/test_vision.py
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from langchain_core.messages import HumanMessage
from config import PipelineConfig
from llm_client import LLMClient
from storage import StoryStorage

cfg = PipelineConfig()
storage = StoryStorage(cfg)
sheets = storage.discover_character_sheets()
assert sheets, "no sheets in input/"

path = next(iter(sheets.values()))
print(f"Testing: {path} ({path.stat().st_size} bytes)")

b64 = storage.read_image_b64(path)
llm = LLMClient(cfg).chat_model(temperature=0.0, timeout=120)
msg = HumanMessage(content=[
    {"type": "text", "text":
        "Describe this image in one sentence. Include hair color, hair style, "
        "and clothing. Reply with only the sentence."},
    {"type": "image_url",
     "image_url": {"url": f"data:image/png;base64,{b64}"}},
])
print("Sending...")
print(llm.invoke([msg]).content)
