"""All Pydantic schemas. Closed vocabularies use Literal types."""
from typing import List, Literal, Optional, Sequence

from pydantic import BaseModel, ConfigDict, Field, create_model, field_validator

from templates import COLOR_GRADES, STYLE_PRESETS, VOCABULARIES


def _lit(values: Sequence):
    return Literal[tuple(values)]


# =========================== Stage 1 ===========================
class ProjectLLM(BaseModel):
    title: str = Field(description="Short movie title, 3-6 words.")
    style_preset: _lit(list(STYLE_PRESETS))
    color_grade: _lit(COLOR_GRADES)


# =========================== character.json ====================
class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CharHair(_Strict):
    length: Literal["bald", "short", "chin_length", "shoulder_length", "mid_back", "waist_length"]
    style: Literal["straight", "wavy", "curly", "braided", "bun", "ponytail", "tied_back", "other"]
    color: Literal["black", "dark_brown", "brown", "light_brown", "blonde", "red", "grey", "white"]


class CharIdentity(_Strict):
    age_range: Literal["child", "teen", "young_adult", "adult", "middle_aged", "senior"]
    build: Literal["slim", "average", "athletic", "curvy", "stocky", "heavy"]
    face_shape: Literal["oval", "round", "square", "heart", "long"]
    skin_tone: Literal["fair", "light", "medium", "olive", "tan", "brown", "dark_brown", "deep"]
    eye_color: Literal["black", "dark_brown", "brown", "hazel", "green", "blue", "grey"]
    hair: CharHair
    facial_hair: Literal["none", "stubble", "mustache", "beard"]
    facial_marks: List[str] = Field(default_factory=list, max_length=3)
    accessories: List[str] = Field(default_factory=list, max_length=4)


class CharGarment(_Strict):
    type: str = Field(max_length=30)
    color: str = Field(max_length=30)
    pattern: Literal["solid", "striped", "floral", "checked", "printed", "other"]


class CharWardrobe(_Strict):
    wardrobe_id: str = Field(pattern=r"^wd_\d{2}$")
    text: str = Field(min_length=10, max_length=200)
    garments: List[CharGarment] = Field(min_length=1, max_length=5)
    footwear: str = Field(max_length=40)
    states: dict[str, str]

    @field_validator("states")
    @classmethod
    def _states_ok(cls, v):
        import re
        if "default" not in v:
            raise ValueError("states must contain 'default'")
        if len(v) > 5:
            raise ValueError("states has more than 5 entries")
        for k in v:
            if not re.match(r"^[a-z][a-z_]*$", k):
                raise ValueError(f"state key '{k}' must be snake_case")
        return v


class CharSheetCheck(_Strict):
    full_body: bool
    plain_background: bool
    views_visible: List[Literal["front", "side", "back", "three_quarter"]]
    issues: List[str] = Field(default_factory=list)


class CharReview(_Strict):
    source: Literal["vision", "manual"]
    reviewed: bool
    uncertain_fields: List[str] = Field(default_factory=list)


class CharacterEntry(_Strict):
    character_id: str = Field(pattern=r"^char_\d{2}$")
    name: str = Field(min_length=1, max_length=30)
    subject: Literal["woman", "man", "girl", "boy", "person"]
    sheet_file: str = Field(pattern=r"^char_\d{2}_sheet\.png$")
    identity: CharIdentity
    identity_lock: str = Field(min_length=40, max_length=300)
    wardrobe: List[CharWardrobe] = Field(min_length=1, max_length=2)
    sheet_check: CharSheetCheck
    review: CharReview


class CharacterFile(_Strict):
    schema_version: Literal["1.0"]
    characters: List[CharacterEntry] = Field(min_length=1, max_length=1)


# =========================== Stage 2 (one window) ==============
class EnvironmentLLM(BaseModel):
    name: str = Field(description="Short place name, 2-4 words.")
    description: str = Field(description="One plain sentence: what the place looks like. No people.")
    ambience: str = Field(description="Short phrase: the sounds of the place.")


class PropLLM(BaseModel):
    name: str = Field(description="Short object name.")
    text: str = Field(description="One plain sentence: what it looks like.")


class AssetsWindowLLM(BaseModel):
    environments: List[EnvironmentLLM] = Field(default_factory=list, max_length=3)
    props: List[PropLLM] = Field(default_factory=list, max_length=3)


# =========================== Stage 3 (one clip per call) =======
def make_clip_model(env_ids: Sequence[str]):
    return create_model(
        "ClipLLM",
        done=(bool, Field(description="True only when no action is left in the story part.")),
        name=(str, Field(description="2-4 words.")),
        action=(str, Field(description="One short sentence. One action.")),
        place=(_lit(env_ids), ...),
        time=(_lit(VOCABULARIES["time_of_day"]), ...),
        person=(bool, Field(description="True when the person is seen doing the action.")),
        last_words=(str, Field(description="3 story words where the action ends.")),
    )


# =========================== Stage 4 ===========================
class Shot(BaseModel):
    shot_type: _lit(VOCABULARIES["shot_type"])
    camera_angle: _lit(VOCABULARIES["camera_angle"])
    camera_movement: _lit(VOCABULARIES["camera_movement"])


# =========================== Stage 5 ===========================
def make_keyframe_models(pose_ids: Sequence[str], prop_ids: Sequence[str]):
    """Return (Full with first+last, End with last only)."""
    State = create_model(
        "KeyframeStateLLM",
        pose_id=(_lit(pose_ids), ...),
        screen_horizontal=(_lit(VOCABULARIES["screen_horizontal"]), ...),
        facing=(_lit(VOCABULARIES["facing"]), ...),
        expression=(_lit(VOCABULARIES["expression"]), ...),
        prop_in_hand=(_lit(prop_ids), ...),
    )
    Full = create_model("KeyframesLLM", first=(State, ...), last=(State, ...))
    End = create_model("KeyframesEndLLM", last=(State, ...))
    return Full, End


# =========================== Stage 6 ===========================
class VideoLLM(BaseModel):
    subject_motion: str = Field(description="Full sentence: what the person does. Empty if nobody.")
    ambient_motion: str = Field(description="Full sentence: wind, water, leaves, light.")