"""Stage 3 - story -> clip files (LLM, windowed) -> 3_scenes.json (code).

3a: the LLM reads a small window, writes the NEXT clip and says where the
    action ends (last_words). Code only moves the cursor and writes files.
3b: code reads output/3_clips/clip_NNN.txt and builds scenes, ids, light.
"""
import re
import time

from langchain_core.prompts import ChatPromptTemplate

from models import make_clip_model
from templates import CLIP_SYSTEM, CLIP_USER, LIGHT_PRESETS, VOCABULARIES
from validate import check_clip_files, report
from .base import PipelineStage, find_end, window_at


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", "", (text or "").lower())).strip()


def build_scenes(clips: list, assets: dict) -> list:
    chars = assets.get("characters") or []
    char_id = chars[0]["character_id"] if chars else ""
    wardrobe_id = chars[0]["wardrobe"][0]["wardrobe_id"] if chars else ""
    env_by_id = {e["environment_id"]: e for e in assets["environments"]}

    scenes, cur, cur_key = [], None, None
    for c in clips:
        key = (c["place"], c["time"])
        env, tod = env_by_id[c["place"]], c["time"]
        if cur is None or key != cur_key:
            n = len(scenes) + 1
            cur = {
                "scene_id":     f"s{n:02d}",
                "scene_number": n,
                "name":         f"{env['name']} - {tod.replace('_', ' ')}",
                "summary":      "",
                "environment_ref": {"environment_id": env["environment_id"]},
                "time_of_day":  tod,
                "weather":      "clear",
                "light":        dict(LIGHT_PRESETS[tod]),
                "characters_present": [],
                "ambience":     env.get("ambience", ""),
                "segments":     [],
            }
            scenes.append(cur)
            cur_key = key

        seg_n = len(cur["segments"]) + 1
        seg_id = f"{cur['scene_id']}.sg{seg_n:02d}"
        clip = {
            "clip_id":      f"{seg_id}.c001",
            "clip_number":  1,
            "name":         c["name"],
            "story_action": c["action"],
            "duration_sec": 5,
            "continuity": {
                "transition_in": "hard_cut" if seg_n == 1 else "continuous_from_previous",
                "framing_locked": True,
            },
            "wardrobe_id":       wardrobe_id,
            "character_present": bool(c["person"] and char_id),
        }
        cur["segments"].append({
            "segment_id":     seg_id,
            "segment_number": seg_n,
            "name":           c["name"],
            "beat_summary":   c["action"],
            "emotional_arc":  "",
            "clips":          [clip],
        })

    for scene in scenes:
        cl = [x for sg in scene["segments"] for x in sg["clips"]]
        scene["summary"] = "; ".join(x["story_action"] for x in cl)
        if any(x["character_present"] for x in cl):
            scene["characters_present"] = [char_id]
    return scenes


class Stage3Breakdown(PipelineStage):
    def __init__(self, llm, storage, force: bool = False):
        super().__init__(llm, storage)
        self._force = force

    def run(self) -> None:
        if self._force:
            print("Note: --force deletes output/3_clips/ - hand edits to clip files are lost.")
            self._storage.delete_clips()
            self._storage.delete_scenes()
        if self._storage.scenes_exists():
            print("Stage 3 already complete (output/3_scenes.json). Use --force to regenerate.\n"
                  "To rebuild scenes after editing clip files, delete output/3_scenes.json.")
            return
        if not self._check_inputs(need_story=True):
            return
        if not self._storage.project_exists() or not self._storage.assets_exists():
            print("Error: Missing output/1_project.json or output/2_assets.json.")
            return

        assets = self._storage.read_assets()["assets"]
        env_ids = [e["environment_id"] for e in assets["environments"]]

        # --- 3a: clip files ---------------------------------------------
        if self._storage.clips_exist():
            print("Reusing existing clip files in output/3_clips/.")
        else:
            self._generate_clips(assets, env_ids)
        if not self._storage.clips_exist():
            print("Error: no clips were produced.")
            return

        # --- 3b: scenes --------------------------------------------------
        clips = self._storage.read_clip_files()
        issues = check_clip_files(clips, env_ids)
        if report(issues, "clips"):
            print("Fix the clip files and re-run this stage.")
            return
        scenes = build_scenes(clips, assets)
        self._storage.write_scenes({"schema_version": "2.0", "scenes": scenes})
        print(f"Wrote {self._storage._config.scenes_path} "
              f"({len(scenes)} scenes, {len(clips)} clips)")

    # ------------------------------------------------------------------
    def _generate_clips(self, assets: dict, env_ids: list) -> None:
        cfg = self._llm._config
        story = self._storage.read_story()
        model = make_clip_model(env_ids)
        llm = self._llm.structured(model, temperature=cfg.clips_temperature)
        prompt = ChatPromptTemplate.from_messages([
            ("system", CLIP_SYSTEM),
            ("human",  CLIP_USER),
        ])
        chain = prompt | llm

        clips: list = []
        cursor, attempts = 0, 0
        place, time_of_day = "(not set yet)", "(not set yet)"
        t0 = time.perf_counter()
        print("Calling LLM for clips (one clip per call)...")

        while len(clips) < cfg.max_clips:
            window, wstart = window_at(story, cursor, cfg.clip_window_words)
            if not window:
                break
            done_text = "\n".join(f"- {c['action']}" for c in clips[-cfg.memory_clips:]) \
                or "(none yet)"
            try:
                r = self._invoke_with_retry(chain, {
                    "window":        window,
                    "done_clips":    done_text,
                    "current_place": place,
                    "current_time":  time_of_day,
                    "place_list":    ", ".join(env_ids),
                    "time_list":     ", ".join(VOCABULARIES["time_of_day"]),
                }, prompts=(CLIP_SYSTEM, CLIP_USER))
            except Exception as exc:
                print(f"  error: {exc}")
                break

            if r.done:
                break
            action = " ".join(r.action.split())
            if not action:
                attempts += 1
                if attempts >= 3:
                    cursor = self._half_window(story, cursor, cfg.clip_window_words)
                    attempts = 0
                continue

            end = find_end(window, wstart, r.last_words)
            if end is None and attempts < 2:
                attempts += 1
                print(f"  last_words not found ({r.last_words!r}); retrying")
                continue
            attempts = 0
            if end is None:
                print("  warning: cursor moved by half a window")
                end = self._half_window(story, cursor, cfg.clip_window_words)

            if clips and _norm(action) == _norm(clips[-1]["action"]):
                print(f"  skipped exact repeat: {action!r}")
                cursor = end
                continue

            clip = {"name": r.name.strip() or action[:30], "action": action,
                    "place": r.place, "time": r.time, "person": r.person}
            clips.append(clip)
            self._storage.write_clip_file(len(clips), clip)
            place, time_of_day = r.place, r.time
            cursor = end
            print(f"  clip_{len(clips):03d}: {action}")

        print(f"LLM clips took {time.perf_counter() - t0:.2f}s ({len(clips)} clips)")
        if len(clips) >= cfg.max_clips:
            print(f"Warning: stopped at max_clips ({cfg.max_clips}).")

    @staticmethod
    def _half_window(story: str, cursor: int, window_words: int) -> int:
        w, start = window_at(story, cursor, max(1, window_words // 2))
        return start + len(w) if w else len(story)