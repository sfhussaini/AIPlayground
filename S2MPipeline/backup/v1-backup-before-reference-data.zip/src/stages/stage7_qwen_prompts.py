"""Stage 7 - render image_gen.rendered_prompt for every generated keyframe.

Pure code, no LLM. The ONLY place Qwen prompts are built. Always re-renders
everything, so it can never hold stale text. Every prompt is complete on its
own: environment, identity, outfit, pose, position, light, style.
"""
import time

from templates import (
    CONDITION_TEXT, DEPTH_LABELS, FACING_LABELS, HORIZONTAL_LABELS, NEGATIVES_STILL,
    PROMPT_TEMPLATES,
)
from .base import PipelineStage, iter_clips, render_sentences


class Stage7QwenPrompts(PipelineStage):
    def __init__(self, llm, storage, force: bool = False, limit: int | None = None):
        super().__init__(llm, storage)
        self._limit = limit

    def run(self) -> None:
        st, cfg = self._storage, self._llm._config

        if st.motion_exists() and not st.is_newer(cfg.scenes_keyframes_path, cfg.motion_path):
            data = st.read_motion()
            print(f"Loaded {cfg.motion_path}")
        elif st.scenes_keyframes_exists():
            data = self.assemble_tree(
                st.read_scenes_keyframes()["scenes"],
                st.read_assets()["assets"], st.read_project()["project"])
            print(f"Loaded {cfg.scenes_keyframes_path} (motion not run yet or out of date)")
        else:
            print("Error: Missing output/5_scenes-keyframes.json. Run stage 'keyframes' first.")
            return

        assets = data.get("assets") or {}
        style_bible = (data.get("project") or {}).get("style_bible") or {}
        negative = ", ".join(style_bible.get("global_negative_terms") or NEGATIVES_STILL)

        rendered = failed = 0
        t0 = time.perf_counter()
        for scene, _, clip in iter_clips(data):
            for role in ("first", "middle", "last"):
                kf = (clip.get("keyframes") or {}).get(role)
                ig = (kf or {}).get("image_gen")
                if not ig:
                    continue
                if self._limit is not None and rendered >= self._limit:
                    ig["rendered_prompt"] = None
                    continue
                try:
                    ig["rendered_prompt"] = self._render_keyframe(
                        kf, clip, scene, assets, style_bible)
                    ig["negative_prompt"] = negative
                    rendered += 1
                except Exception as exc:
                    failed += 1
                    print(f"  error on {kf.get('keyframe_id')}: {exc}")

        st.write_qwen_prompts(data)
        print("\n" + "=" * 60)
        print(f"Stage 7 done in {time.perf_counter() - t0:.2f}s. Rendered: {rendered}  Failed: {failed}")
        print(f"File: {cfg.qwen_prompts_path}")

    # ------------------------------------------------------------------
    @staticmethod
    def _render_keyframe(kf, clip, scene, assets, style_bible) -> str:
        ig = kf["image_gen"]
        state = kf.get("state") or {}
        character = next((c for c in assets.get("characters", [])
                          if c["character_id"] == state.get("character_id")), None)
        wardrobe = next((w for w in (character or {}).get("wardrobe", [])
                         if w["wardrobe_id"] == clip.get("wardrobe_id")), None)
        env = next((e for e in assets.get("environments", [])
                    if e["environment_id"] == scene["environment_ref"]["environment_id"]), {})
        pose = next((p for p in assets.get("pose_library", [])
                     if p["pose_id"] == state.get("pose_id")), {})
        prop = next((p for p in assets.get("props", [])
                     if p["prop_id"] == state.get("prop_in_hand")), {})
        shot = clip.get("shot") or {}
        light = scene.get("light") or {}
        cond = state.get("condition") or {}

        h = HORIZONTAL_LABELS.get(state.get("screen_horizontal", ""), "")
        position = ", ".join(x for x in (
            f"{h} of the frame" if h else "",
            DEPTH_LABELS.get(state.get("screen_depth", ""), ""),
            FACING_LABELS.get(state.get("facing", ""), ""),
        ) if x)
        condition = "; ".join(
            t for t in (CONDITION_TEXT[f].get(cond.get(f, "")) for f in
                        ("wetness", "mud_level", "hair_state")) if t)
        framing = ""
        if shot.get("shot_type"):
            framing = (f"{shot['shot_type'].replace('_', ' ')} shot, "
                       f"{shot.get('camera_angle', '').replace('_', ' ')}, "
                       f"{shot.get('lens_mm', '')}mm lens")
        style = style_bible.get("visual_style", "")
        grade = style_bible.get("color_grade_default", "")
        if style and grade:
            style = f"{style}, {grade} color grade"

        ctx = {
            "subject":                 (character or {}).get("subject", ""),
            "environment_description": env.get("description", ""),
            "identity_lock":           (character or {}).get("identity_lock", ""),
            "wardrobe_text":           (wardrobe or {}).get("text", ""),
            "wardrobe_state_text":     ((wardrobe or {}).get("states") or {}).get(
                                           state.get("wardrobe_state", ""), ""),
            "framing_text":            framing,
            "pose_text":               pose.get("text", ""),
            "position_text":           position,
            "expression_text":         state.get("expression", ""),
            "prop_text":               prop.get("text") or prop.get("name", ""),
            "condition_text":          condition,
            "light_text":              ", ".join(
                x for x in (light.get(k) for k in ("source", "direction", "quality", "color_temp")) if x),
            "style_text":              style,
        }
        return render_sentences(PROMPT_TEMPLATES[ig["template_id"]], ctx)